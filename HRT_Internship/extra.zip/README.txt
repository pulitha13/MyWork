Files Included:
------------------

1) alu_onestg.sv

This is the one stage ALU that I used for testing purposes

2) secret_one_stage

This is the Modelsim transcript output when using alu_onestg.sv
with the secret.hex instruction set. 

3) secret_two_stage

This is the Modelsim transcript output when using alu.sv
with the secret.hex instruction set. 